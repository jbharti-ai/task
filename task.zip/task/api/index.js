
const express = require('express');
const app = express();
const port = 3000;


app.use(express.json());


let courses = [
    { id: 1, title: 'Math 101', description: 'Basic Mathematics', duration: '3 months' },
    { id: 2, title: 'Physics 101', description: 'Fundamentals of Physics', duration: '4 months' }
];


app.get('/courses', (req, res) => {
    res.json(courses);
});


app.get('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const course = courses.find(c => c.id === courseId);
    if (!course) {
        return res.status(404).json({ message: 'Course not found' });
    }
    res.json(course);
});


app.post('/courses', (req, res) => {
    const newCourse = {
        id: courses.length + 1, 
        title: req.body.title,
        description: req.body.description,
        duration: req.body.duration
    };
    courses.push(newCourse);
    res.status(201).json(newCourse);
});


app.put('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const course = courses.find(c => c.id === courseId);

    if (!course) {
        return res.status(404).json({ message: 'Course not found' });
    }

    
    course.title = req.body.title;
    course.description = req.body.description;
    course.duration = req.body.duration;

    res.json(course);
});


app.delete('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    courses = courses.filter(c => c.id !== courseId);
    res.json({ message: 'Course deleted successfully' });
});


app.listen(port, () => {
    console.log(`Course API listening at http://localhost:${port}`);
});
